
module.exports = function(wtf){
   var thisisnotnull = wtf.match(/[+-]?\d+(\.\d+)?$/);
   return thisisnotnull
}
